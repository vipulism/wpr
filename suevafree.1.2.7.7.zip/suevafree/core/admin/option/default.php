<?php

$fontsize = array ("9px" => "9px", "10px" => "10px", "11px" => "11px", "12px" => "12px", "13px" => "13px", "14px" => "14px", "15px" => "15px", "16px" => "16px", "17px" => "17px", "18px" => "18px", "19px" => "19px", "20px" => "20px", "21px" => "21px", "22px" => "22px", "23px" => "23px", "24px" => "24px", "25px" => "25px", "26px" => "26px", "27px" => "27px", "28px" => "28px", "29px" => "29px", "30px" => "30px", "31px" => "31px", "32px" => "32px", "33px" => "33px", "34px" => "34px", "35px" => "35px", "36px" => "36px", "37px" => "37px", "38px" => "38px", "39px" => "39px", "40px" => "40px", "41px" => "41px", "42px" => "42px", "43px" => "43px", "44px" => "44px", "45px" => "45px", "46px" => "46px", "47px" => "47px", "48px" => "48px", "49px" => "49px", "50px" => "50px", "51px" => "51px", "52px" => "52px", "53px" => "53px", "54px" => "54px", "55px" => "55px", "56px" => "56px", "57px" => "57px", "58px" => "58px", "59px" => "59px", "60px" => "60px", "61px" => "61px", "62px" => "62px", "63px" => "63px", "64px" => "64px", "65px" => "65px", "66px" => "66px", "67px" => "67px", "68px" => "68px", "69px" => "69px", "70px" => "70px");

$backgrounds = array( 
				"none" => "None",
				"/images/background/patterns/pattern1.jpg" => "Pattern 01",
		   		"/images/background/patterns/pattern2.jpg" => "Pattern 02",
		   		"/images/background/patterns/pattern3.jpg" => "Pattern 03",
		   		"/images/background/patterns/pattern4.jpg" => "Pattern 04",
		   		"/images/background/patterns/pattern5.jpg" => "Pattern 05",
		   		"/images/background/patterns/pattern6.jpg" => "Pattern 06",
		   		"/images/background/patterns/pattern7.jpg" => "Pattern 07",
		   		"/images/background/patterns/pattern8.jpg" => "Pattern 08",
);

?>