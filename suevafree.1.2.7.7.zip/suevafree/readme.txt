Sueva Free Wordpress Theme
---------------------
Sueva is a free responsive clean and corporate Tumblelog Wordpress Theme. The theme support all modern browsers like Firefox, Chrome, Safari, Opera and Internet Explorer 8, 9 and 10 and uses the most modern technologies like Html5 and Css3.

Created by ThemeinProgress, http://www.themeinprogress.com 
Demo: http://www.wpinprogress.com/demo/sueva


License
-------
Sueva is licensed under the GPL.


Credits
-------

/** IMAGES **/

- Patters

-- By Theme in Progress - http://www.themeinprogress.com

--- Licensed under GNU General Public License v3.

/** ICONS **/

- Font Awesome

-- By Dave Gandy - http://fortawesome.github.io/Font-Awesome/

--- Font License under SIL OFL 1.1 - http://scripts.sil.org/OFL ( Applies to all desktop and webfont files in the following directory: /sueva/fonts/ )
--- Code License under MIT License - http://opensource.org/licenses/mit-license.html ( Applies to the font-awesome.min.css file in /sueva/css/ )
--- Brand Icons - All brand icons are trademarks of their respective owners. The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.

/** FONTS **/

- Google Web Fonts

-- By Google - http://google.com

--- License - https://developers.google.com/fonts/faq?hl=it-IT#Any_Page_OK

/** FRAMEWORK **/

- Twitter Bootstrap

-- By Twitter Bootstrap - http://getbootstrap.com/2.3.2/

--- Licensed under Apache License v2.0

/** JQUERY **/

- Jquery

-- By Jquery - https://jquery.org

--- Licensed under MIT License

- Jquery UI

-- By Jquery - http://jqueryui.com/

--- Licensed under MIT License 

- Jquery Easing:

-- By George McGinley Smith - http://gsgd.co.uk/sandbox/jquery/easing/

--- Licensed under BSD License

/* VARIOUS */

- Tipsy:

-- By Jason Frame - http://onehackoranother.com/projects/jquery/tipsy/

--- Licensed under MIT License

- Tinynav:

-- By Viljamis - http://tinynav.viljamis.com

--- Licensed under MIT License

- Pretty Photo:

-- By Pretty Photo - http://www.no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/

--- Licensed under GPLv2 or Creative Commons 2.5 license